#!/bin/bash

# Create Final App Bundle for Elevate
# This script creates a comprehensive app bundle with all components integrated
# including the Android app, verification website, and all documentation

echo "Creating final Elevate app bundle..."
echo "====================================="

# Create output directory
OUTPUT_DIR="/home/ubuntu/elevate_final_bundle"
mkdir -p $OUTPUT_DIR

# Create timestamp for versioning
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BUNDLE_NAME="elevate_app_bundle_$TIMESTAMP"
BUNDLE_DIR="$OUTPUT_DIR/$BUNDLE_NAME"
mkdir -p $BUNDLE_DIR

# Create directory structure
mkdir -p $BUNDLE_DIR/android_app
mkdir -p $BUNDLE_DIR/verification_website
mkdir -p $BUNDLE_DIR/documentation
mkdir -p $BUNDLE_DIR/branding
mkdir -p $BUNDLE_DIR/marketing
mkdir -p $BUNDLE_DIR/game_elements

# Copy Android app with updated elements
echo "Copying Android app with game elements and updated typography..."
cp -r /home/ubuntu/membership_app_project/app_development/elevate/* $BUNDLE_DIR/android_app/

# Update app resources with new game elements
mkdir -p $BUNDLE_DIR/android_app/app/src/main/res/drawable-xxhdpi/
cp /home/ubuntu/membership_app_project/game_elements/mockups/*.png $BUNDLE_DIR/android_app/app/src/main/res/drawable-xxhdpi/

# Copy verification website
echo "Copying verification website..."
cp -r /home/ubuntu/membership_app_project/verification_website/* $BUNDLE_DIR/verification_website/

# Copy documentation with updated information
echo "Copying updated documentation..."
cp -r /home/ubuntu/membership_app_project/documentation/* $BUNDLE_DIR/documentation/

# Update location information in documentation
echo "Updating location information to Florida, USA..."
find $BUNDLE_DIR/documentation -type f -name "*.md" -exec sed -i 's/Location: .*/Location: Florida, USA/g' {} \;

# Copy branding assets
echo "Copying branding assets with updated typography..."
cp -r /home/ubuntu/membership_app_project/branding/* $BUNDLE_DIR/branding/
cp -r /home/ubuntu/membership_app_project/logo_design/logo/* $BUNDLE_DIR/branding/

# Copy marketing materials
echo "Copying marketing materials..."
cp -r /home/ubuntu/membership_app_project/marketing/* $BUNDLE_DIR/marketing/

# Copy game elements design and mockups
echo "Copying game elements design and mockups..."
cp -r /home/ubuntu/membership_app_project/game_elements/* $BUNDLE_DIR/game_elements/

# Create README file
echo "Creating README file..."
cat > $BUNDLE_DIR/README.md << EOF
# Elevate App Bundle

## Overview
This is the complete bundle for the Elevate membership app, including all components needed for deployment.

## Location
Florida, USA

## Components
1. **Android App**: Complete source code with game-inspired elements and updated typography
2. **Verification Website**: Frontend and backend code for the verification portal
3. **Documentation**: Comprehensive guides, technical documentation, and user manuals
4. **Branding**: Logo files, visual identity guidelines, and design assets
5. **Marketing**: Marketing plan and promotional materials
6. **Game Elements**: Design specifications and mockups for game-inspired features

## Typography
- Primary Heading Font: Orbitron
- Secondary Font: Exo 2

## Deployment Instructions
See the detailed deployment guides in the documentation directory for step-by-step instructions on:
- Deploying the Android app to Google Play Store
- Deploying the verification website to elevateapp.com
- Setting up user authentication and subscription management

## Contact
For support or questions, contact us at support@elevateapp.com
EOF

# Create deployment guide
echo "Creating deployment guide..."
cat > $BUNDLE_DIR/DEPLOYMENT.md << EOF
# Elevate App Deployment Guide

## Android App Deployment

### Prerequisites
1. Google Play Developer Account
2. Keystore file for app signing
3. App bundle (.aab) file

### Steps
1. Sign the app bundle using the keystore
   \`\`\`
   ./gradlew bundleRelease
   \`\`\`
2. Upload the signed app bundle to Google Play Console
3. Complete the store listing with screenshots and descriptions
4. Set up in-app products for the membership tiers
5. Submit for review

## Verification Website Deployment

### Prerequisites
1. Web hosting with Node.js support
2. Domain access for elevateapp.com
3. SSL certificate

### Steps
1. Upload the verification_website directory to your hosting provider
2. Install dependencies:
   \`\`\`
   npm install
   \`\`\`
3. Configure environment variables for database connection
4. Start the server:
   \`\`\`
   node server.js
   \`\`\`
5. Set up SSL certificate for secure connections

## Database Setup
1. Create a MongoDB database for user data
2. Configure the connection string in server.js
3. Run the initial database setup script:
   \`\`\`
   node setup_database.js
   \`\`\`

## Integration Testing
After deployment, verify:
1. User registration and login flow
2. Membership tier upgrades
3. Verification process between app and website
4. Payment processing
EOF

# Create version history
echo "Creating version history..."
cat > $BUNDLE_DIR/VERSION_HISTORY.md << EOF
# Elevate App Version History

## Version 1.0.0 - Initial Release
- Four membership tiers: Essentials, Plus, Pro, and Elite
- Complete set of tools, workflows, insights, and discoveries
- User authentication and account management
- Verification website integration

## Version 1.1.0 - Typography Update
- Updated typography to Orbitron and Exo 2
- Enhanced visual design with cosmic imagery
- Location updated to Sarasota, FL, USA

## Version 1.2.0 - Excitement Update (Current)
- Added game-inspired elements for increased engagement
- Implemented achievement system with visual rewards
- Added streak counters and progress tracking
- Enhanced animations and transitions
- Added daily challenges and reward mechanics
EOF

# Create final bundle
echo "Creating final zip archive..."
cd $OUTPUT_DIR
zip -r "${BUNDLE_NAME}.zip" $BUNDLE_NAME

echo "Final app bundle created successfully!"
echo "Location: $OUTPUT_DIR/${BUNDLE_NAME}.zip"
echo "This bundle contains everything needed to deploy the Elevate app with all new features."
