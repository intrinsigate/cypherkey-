const { createCanvas } = require('canvas');
const fs = require('fs');
const path = require('path');

// Create directory for game element mockups
const outputDir = path.join(__dirname, 'mockups');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir);
}

// Helper function to create a canvas
function createGameCanvas(width, height, filename) {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');
  
  // Background gradient - cosmic theme
  const bgGradient = ctx.createLinearGradient(0, 0, 0, height);
  bgGradient.addColorStop(0, '#0B0B2A');
  bgGradient.addColorStop(0.5, '#1A1A4A');
  bgGradient.addColorStop(1, '#0D0D35');
  
  ctx.fillStyle = bgGradient;
  ctx.fillRect(0, 0, width, height);
  
  // Add some stars/particles
  for (let i = 0; i < 100; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const radius = Math.random() * 1.5;
    const opacity = Math.random() * 0.8 + 0.2;
    
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
    ctx.fill();
  }
  
  return { canvas, ctx, filename };
}

// Function to save canvas to file
function saveCanvas(canvas, filename) {
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(path.join(outputDir, filename), buffer);
  console.log(`Created ${filename}`);
}

// 1. Achievement Unlock Animation
function createAchievementUnlock() {
  const { canvas, ctx, filename } = createGameCanvas(800, 600, 'achievement_unlock.png');
  
  // Achievement badge
  ctx.beginPath();
  ctx.arc(400, 200, 80, 0, Math.PI * 2);
  const badgeGradient = ctx.createRadialGradient(400, 200, 0, 400, 200, 80);
  badgeGradient.addColorStop(0, '#6A5ACD');
  badgeGradient.addColorStop(0.7, '#4B0082');
  badgeGradient.addColorStop(1, '#2E0854');
  ctx.fillStyle = badgeGradient;
  ctx.fill();
  
  // Badge border
  ctx.beginPath();
  ctx.arc(400, 200, 80, 0, Math.PI * 2);
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#FFD700';
  ctx.stroke();
  
  // Badge icon
  ctx.beginPath();
  ctx.moveTo(370, 180);
  ctx.lineTo(390, 220);
  ctx.lineTo(430, 170);
  ctx.lineWidth = 8;
  ctx.strokeStyle = '#00FFFF';
  ctx.stroke();
  
  // Particle burst effect
  for (let i = 0; i < 40; i++) {
    const angle = Math.random() * Math.PI * 2;
    const distance = Math.random() * 150 + 100;
    const x = 400 + Math.cos(angle) * distance;
    const y = 200 + Math.sin(angle) * distance;
    const size = Math.random() * 8 + 2;
    
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fillStyle = i % 3 === 0 ? '#FFD700' : i % 3 === 1 ? '#00FFFF' : '#FF00FF';
    ctx.globalAlpha = Math.random() * 0.5 + 0.5;
    ctx.fill();
    ctx.globalAlpha = 1;
  }
  
  // Achievement text
  ctx.font = 'bold 40px Orbitron';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('ACHIEVEMENT UNLOCKED!', 400, 350);
  
  // Achievement name
  ctx.font = '30px Exo 2';
  ctx.fillStyle = '#00FFFF';
  ctx.fillText('Mindfulness Master', 400, 400);
  
  // XP reward
  ctx.font = 'bold 24px Exo 2';
  ctx.fillStyle = '#FFD700';
  ctx.fillText('+250 XP', 400, 450);
  
  saveCanvas(canvas, filename);
}

// 2. Progress Bar Animation
function createProgressBar() {
  const { canvas, ctx, filename } = createGameCanvas(800, 400, 'progress_bar.png');
  
  // Progress bar background
  ctx.beginPath();
  ctx.roundRect(100, 150, 600, 40, 20);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.fill();
  
  // Progress bar fill
  ctx.beginPath();
  ctx.roundRect(100, 150, 420, 40, 20);
  const progressGradient = ctx.createLinearGradient(100, 0, 700, 0);
  progressGradient.addColorStop(0, '#4B0082');
  progressGradient.addColorStop(0.5, '#6A5ACD');
  progressGradient.addColorStop(1, '#00FFFF');
  ctx.fillStyle = progressGradient;
  ctx.fill();
  
  // Progress particles
  for (let i = 0; i < 15; i++) {
    const x = 100 + 420 * Math.random();
    const y = 150 + 40 * Math.random();
    const size = Math.random() * 6 + 2;
    
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
    ctx.fill();
  }
  
  // Glow effect at progress edge
  const glowGradient = ctx.createRadialGradient(520, 170, 0, 520, 170, 40);
  glowGradient.addColorStop(0, 'rgba(0, 255, 255, 0.8)');
  glowGradient.addColorStop(1, 'rgba(0, 255, 255, 0)');
  ctx.fillStyle = glowGradient;
  ctx.fillRect(480, 130, 80, 80);
  
  // Progress text
  ctx.font = 'bold 24px Orbitron';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('DAILY GOAL: 70%', 400, 100);
  
  // Percentage
  ctx.font = 'bold 20px Exo 2';
  ctx.fillStyle = '#00FFFF';
  ctx.fillText('70%', 520, 178);
  
  saveCanvas(canvas, filename);
}

// 3. Streak Counter
function createStreakCounter() {
  const { canvas, ctx, filename } = createGameCanvas(800, 400, 'streak_counter.png');
  
  // Streak background
  ctx.beginPath();
  ctx.arc(400, 150, 80, 0, Math.PI * 2);
  const streakGradient = ctx.createRadialGradient(400, 150, 0, 400, 150, 80);
  streakGradient.addColorStop(0, '#FF5500');
  streakGradient.addColorStop(0.7, '#FF0066');
  streakGradient.addColorStop(1, '#990033');
  ctx.fillStyle = streakGradient;
  ctx.fill();
  
  // Streak pulse effect
  ctx.beginPath();
  ctx.arc(400, 150, 90, 0, Math.PI * 2);
  ctx.lineWidth = 5;
  ctx.strokeStyle = 'rgba(255, 85, 0, 0.5)';
  ctx.stroke();
  
  ctx.beginPath();
  ctx.arc(400, 150, 100, 0, Math.PI * 2);
  ctx.lineWidth = 3;
  ctx.strokeStyle = 'rgba(255, 85, 0, 0.3)';
  ctx.stroke();
  
  ctx.beginPath();
  ctx.arc(400, 150, 110, 0, Math.PI * 2);
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgba(255, 85, 0, 0.1)';
  ctx.stroke();
  
  // Streak number
  ctx.font = 'bold 60px Orbitron';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('7', 400, 150);
  
  // Streak text
  ctx.font = 'bold 30px Exo 2';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('DAY STREAK', 400, 250);
  
  // Streak reward
  ctx.font = '20px Exo 2';
  ctx.fillStyle = '#FFD700';
  ctx.fillText('Keep it up! 3 days until next reward', 400, 290);
  
  // Flame effects
  for (let i = 0; i < 20; i++) {
    const angle = Math.random() * Math.PI - Math.PI/2;
    const distance = Math.random() * 30 + 80;
    const x = 400 + Math.cos(angle) * distance;
    const y = 150 + Math.sin(angle) * distance - 20;
    const size = Math.random() * 15 + 5;
    
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x + size/2, y - size, x + size, y);
    ctx.quadraticCurveTo(x + size/2, y - size/2, x, y);
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255, 165, 0, 0.7)' : 'rgba(255, 69, 0, 0.7)';
    ctx.fill();
  }
  
  saveCanvas(canvas, filename);
}

// 4. Level Up Animation
function createLevelUp() {
  const { canvas, ctx, filename } = createGameCanvas(800, 600, 'level_up.png');
  
  // Level up text
  ctx.font = 'bold 70px Orbitron';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  
  // Text glow effect
  ctx.shadowColor = '#00FFFF';
  ctx.shadowBlur = 20;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('LEVEL UP!', 400, 150);
  ctx.shadowBlur = 0;
  
  // Level indicator
  ctx.font = 'bold 50px Exo 2';
  ctx.fillStyle = '#00FFFF';
  ctx.fillText('LEVEL 5', 400, 230);
  
  // Starburst effect
  for (let i = 0; i < 16; i++) {
    const angle = i * Math.PI / 8;
    ctx.beginPath();
    ctx.moveTo(400, 150);
    ctx.lineTo(400 + Math.cos(angle) * 300, 150 + Math.sin(angle) * 300);
    ctx.lineWidth = 3;
    ctx.strokeStyle = 'rgba(0, 255, 255, 0.4)';
    ctx.stroke();
  }
  
  // Circular pulse
  for (let i = 0; i < 3; i++) {
    ctx.beginPath();
    ctx.arc(400, 150, 100 + i * 50, 0, Math.PI * 2);
    ctx.lineWidth = 5 - i;
    ctx.strokeStyle = `rgba(0, 255, 255, ${0.7 - i * 0.2})`;
    ctx.stroke();
  }
  
  // Reward unlocked
  ctx.beginPath();
  ctx.roundRect(250, 300, 300, 200, 20);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fill();
  
  ctx.font = 'bold 24px Orbitron';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('REWARDS UNLOCKED', 400, 330);
  
  // Reward items
  const rewards = [
    'New Meditation Tool',
    'Premium Theme',
    '+500 XP Bonus'
  ];
  
  rewards.forEach((reward, index) => {
    const y = 380 + index * 40;
    
    // Checkmark
    ctx.beginPath();
    ctx.arc(280, y, 10, 0, Math.PI * 2);
    ctx.fillStyle = '#00FF00';
    ctx.fill();
    
    ctx.beginPath();
    ctx.moveTo(275, y);
    ctx.lineTo(280, y + 5);
    ctx.lineTo(285, y - 5);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#000000';
    ctx.stroke();
    
    // Reward text
    ctx.font = '20px Exo 2';
    ctx.textAlign = 'left';
    ctx.fillStyle = index === 0 ? '#FFD700' : '#FFFFFF';
    ctx.fillText(reward, 300, y + 5);
  });
  
  saveCanvas(canvas, filename);
}

// 5. Interactive Button
function createInteractiveButton() {
  const { canvas, ctx, filename } = createGameCanvas(800, 400, 'interactive_button.png');
  
  // Normal state
  ctx.beginPath();
  ctx.roundRect(250, 120, 300, 80, 40);
  const buttonGradient = ctx.createLinearGradient(250, 120, 550, 200);
  buttonGradient.addColorStop(0, '#4B0082');
  buttonGradient.addColorStop(1, '#6A5ACD');
  ctx.fillStyle = buttonGradient;
  ctx.fill();
  
  // Button glow
  ctx.beginPath();
  ctx.roundRect(250, 120, 300, 80, 40);
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#00FFFF';
  ctx.stroke();
  
  // Pulse effect
  ctx.beginPath();
  ctx.roundRect(245, 115, 310, 90, 45);
  ctx.lineWidth = 2;
  ctx.strokeStyle = 'rgba(0, 255, 255, 0.5)';
  ctx.stroke();
  
  ctx.beginPath();
  ctx.roundRect(240, 110, 320, 100, 50);
  ctx.lineWidth = 1;
  ctx.strokeStyle = 'rgba(0, 255, 255, 0.3)';
  ctx.stroke();
  
  // Button text
  ctx.font = 'bold 30px Orbitron';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('START SESSION', 400, 160);
  
  // Pressed state (slightly down and to the right)
  ctx.beginPath();
  ctx.roundRect(260, 250, 300, 80, 40);
  ctx.fillStyle = buttonGradient;
  ctx.fill();
  
  // Pressed button shadow (inner)
  ctx.beginPath();
  ctx.roundRect(260, 250, 300, 80, 40);
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#4B0082';
  ctx.stroke();
  
  // Pressed button text (slightly shifted)
  ctx.font = 'bold 30px Orbitron';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('START SESSION', 410, 290);
  
  // State labels
  ctx.font = '20px Exo 2';
  ctx.fillStyle = '#00FFFF';
  ctx.fillText('Normal State', 400, 80);
  ctx.fillText('Pressed State', 400, 220);
  
  // Touch ripple effect
  ctx.beginPath();
  ctx.arc(410, 290, 40, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
  ctx.fill();
  
  ctx.beginPath();
  ctx.arc(410, 290, 60, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
  ctx.fill();
  
  saveCanvas(canvas, filename);
}

// 6. Daily Challenge
function createDailyChallenge() {
  const { canvas, ctx, filename } = createGameCanvas(800, 600, 'daily_challenge.png');
  
  // Challenge card background
  ctx.beginPath();
  ctx.roundRect(150, 100, 500, 400, 20);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fill();
  
  // Card border with glow
  ctx.beginPath();
  ctx.roundRect(150, 100, 500, 400, 20);
  ctx.lineWidth = 3;
  ctx.strokeStyle = '#00FFFF';
  ctx.shadowColor = '#00FFFF';
  ctx.shadowBlur = 10;
  ctx.stroke();
  ctx.shadowBlur = 0;
  
  // Challenge header
  ctx.font = 'bold 36px Orbitron';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('DAILY CHALLENGE', 400, 150);
  
  // Timer
  ctx.beginPath();
  ctx.arc(400, 200, 40, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
  ctx.fill();
  
  ctx.beginPath();
  ctx.arc(400, 200, 40, -Math.PI/2, Math.PI);
  ctx.lineWidth = 5;
  ctx.strokeStyle = '#FFD700';
  ctx.stroke();
  
  ctx.font = 'bold 20px Exo 2';
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText('12:45', 400, 200);
  ctx.font = '14px Exo 2';
  ctx.fillText('REMAINING', 400, 225);
  
  // Challenge description
  ctx.font = 'bold 24px Exo 2';
  ctx.fillStyle = '#00FFFF';
  ctx.fillText('Complete 3 Focus Sessions', 400, 280);
  
  // Progress indicators
  const tasks = [
    { text: 'Morning Focus', complete: true },
    { text: 'Afternoon Focus', complete: true },
    { text: 'Evening Focus', complete: false }
  ];
  
  tasks.forEach((task, index) => {
    const y = 330 + index * 50;
    
    // Checkbox
    ctx.beginPath();
    ctx.roundRect(200, y - 15, 30, 30, 5);
    ctx.fillStyle = task.complete ? '#00FFFF' : 'rgba(255, 255, 255, 0.2)';
    ctx.fill();
    
    if (task.complete) {
      ctx.beginPath();
      ctx.moveTo(205, y);
      ctx.lineTo(215, y + 10);
      ctx.lineTo(225, y - 10);
      ctx.lineWidth = 3;
      ctx.strokeStyle = '#000000';
      ctx.stroke();
    }
    
    // Task text
    ctx.font = '20px Exo 2';
    ctx.textAlign = 'left';
    ctx.fillStyle = task.complete ? '#FFFFFF' : 'rgba(255, 255, 255, 0.7)';
    ctx.fillText(task.text, 250, y);
    
    // Progress dots
    if (task.complete) {
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.arc(500 + i * 10, y, 3, 0, Math.PI * 2);
        ctx.fillStyle = '#00FFFF';
        ctx.fill();
      }
    }
  });
  
  // Reward section
  ctx.beginPath();
  ctx.roundRect(200, 450, 400, 40, 10);
  ctx.fillStyle = 'rgba(255, 215, 0, 0.2)';
  ctx.fill();
  
  ctx.font = 'bold 20px Exo 2';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#FFD700';
  ctx.fillText('REWARD: 300 XP + STREAK BONUS', 400, 475);
  
  saveCanvas(canvas, filename);
}

// Create all mockups
createAchievementUnlock();
createProgressBar();
createStreakCounter();
createLevelUp();
createInteractiveButton();
createDailyChallenge();

console.log('All game element mockups created successfully!');
