# UI Design Style Guide for Elevate App

## Brand Identity

### App Name: Elevate

### Tagline: "Elevate Your Potential"

### Brand Essence
Elevate is a premium membership platform that helps users enhance their personal and professional lives through a unique combination of tools, workflows, insights, discoveries, and entertainment.

## Color Palette

### Primary Colors
- **Royal Purple** (#6A5ACD): Main brand color, represents luxury, creativity, and wisdom
- **Deep Indigo** (#4B0082): Secondary brand color for depth and contrast
- **Soft Gold** (#D4AF37): Accent color for premium elements and highlights

### Secondary Colors
- **Calm Teal** (#45B5AA): For productivity and focus-related elements
- **Warm Coral** (#FF7F50): For entertainment and discovery sections
- **Sage Green** (#9DC183): For wellness and growth-related elements

### Neutral Colors
- **Pure White** (#FFFFFF): Primary background color
- **Soft Cream** (#F8F5F0): Secondary background for cards and panels
- **Light Gray** (#E0E0E0): For subtle separators and inactive elements
- **Medium Gray** (#9E9E9E): For secondary text
- **Charcoal** (#333333): For primary text

### Status Colors
- **Success Green** (#4CAF50): For confirmations and completions
- **Alert Orange** (#FF9800): For warnings and important notifications
- **Error Red** (#F44336): For errors and critical alerts

## Typography

### Primary Font Family: Montserrat
- **Montserrat Light (300)**: For body text and secondary information
- **Montserrat Regular (400)**: For general UI text
- **Montserrat Medium (500)**: For emphasis and subheadings
- **Montserrat SemiBold (600)**: For headings and important UI elements
- **Montserrat Bold (700)**: For primary buttons and main headings

### Secondary Font Family: Playfair Display
- Used sparingly for featured content, quotes, and special headings
- Creates elegant contrast with the primary sans-serif font

### Text Styles
- **Heading 1**: Montserrat Bold, 28px, Charcoal
- **Heading 2**: Montserrat SemiBold, 24px, Charcoal
- **Heading 3**: Montserrat SemiBold, 20px, Charcoal
- **Heading 4**: Montserrat Medium, 18px, Charcoal
- **Body**: Montserrat Regular, 16px, Charcoal
- **Body Small**: Montserrat Regular, 14px, Charcoal
- **Caption**: Montserrat Light, 12px, Medium Gray
- **Button Text**: Montserrat Medium, 16px, White or Charcoal

## UI Components

### Buttons
- **Primary Button**: Royal Purple background, white text, subtle gradient, 8px rounded corners, subtle shadow
- **Secondary Button**: White background, Royal Purple border and text, 8px rounded corners
- **Tertiary Button**: No background, Royal Purple text, no border
- **Disabled Button**: Light Gray background, Medium Gray text
- **Icon Button**: Circular, 40px diameter, Royal Purple or white background

### Cards
- **Standard Card**: White background, subtle shadow, 12px rounded corners, 16px padding
- **Featured Card**: Soft Cream background, medium shadow, 12px rounded corners, 16px padding, Soft Gold accent
- **Tier Card**: Gradient background based on tier level, medium shadow, 12px rounded corners

### Navigation
- **Bottom Navigation**: White background, Royal Purple active indicator, icons with labels
- **Tab Bar**: White background, Royal Purple underline for active tab
- **Drawer Menu**: White background, Royal Purple accent for active item

### Form Elements
- **Text Input**: White background, Light Gray border, 8px rounded corners, 12px padding
- **Dropdown**: White background, Light Gray border, 8px rounded corners, 12px padding
- **Checkbox**: Royal Purple when checked, Light Gray border when unchecked
- **Radio Button**: Royal Purple when selected, Light Gray border when unselected
- **Toggle**: Royal Purple when on, Light Gray when off

### Lists
- **Standard List**: White background, Light Gray separators, 16px vertical padding
- **Featured List**: Soft Cream background, no visible separators, 20px vertical padding

## Iconography

### Style
- **Line Weight**: 2px stroke for outlined icons
- **Corner Radius**: 2px for sharp corners, 4px for rounded elements
- **Style**: Modern, minimalist with occasional decorative elements for premium features

### System Icons
- **Navigation Icons**: Simple, recognizable symbols for main app sections
- **Action Icons**: Clear, intuitive representations of common actions
- **Status Icons**: Distinct shapes for different status indicators

### Custom Icons
- **Tier Badges**: Unique emblems for each membership tier
- **Achievement Icons**: Decorative symbols for user accomplishments
- **Feature Icons**: Distinctive representations of app features

## Imagery

### Photography Style
- **Lifestyle**: Aspirational but authentic images of people using the app features
- **Abstract**: Subtle patterns and textures for backgrounds and accents
- **Conceptual**: Visual metaphors representing growth, elevation, and potential

### Illustration Style
- **Style**: Modern, slightly abstract with organic shapes
- **Color Use**: Limited palette using brand colors
- **Purpose**: Explain concepts, visualize data, and add visual interest

## Animation & Motion

### Principles
- **Purposeful**: Animations serve functional purposes, not just decoration
- **Smooth**: Fluid transitions between states and screens
- **Subtle**: Understated effects that don't distract from content

### Specific Animations
- **Transitions**: Smooth fade and slide effects between screens
- **Feedback**: Subtle scale and color changes for interactive elements
- **Progress**: Elegant loading indicators and progress animations
- **Celebration**: More expressive animations for achievements and milestones

## Accessibility

### Color Contrast
- Minimum 4.5:1 contrast ratio for all text elements
- Alternative visual indicators beyond color alone

### Touch Targets
- Minimum 44x44px for all interactive elements
- Adequate spacing between clickable items

### Text Legibility
- Minimum 14px for body text
- Avoid all-caps text except for short labels
- Line height of at least 1.5 for body text

## Tier-Specific Design Elements

### Essentials (Free)
- Standard UI components
- Limited access indicators for premium features
- Basic animations and transitions

### Plus
- Enhanced card styles with subtle gradients
- Improved animations and transitions
- Custom icons for Plus features

### Pro
- Premium card styles with deeper shadows and refined details
- Advanced animations and transitions
- Exclusive Pro badges and indicators
- Refined typography with more Playfair Display usage

### Elite
- Luxury card styles with gold accents and distinctive details
- Premium animations with polished effects
- Exclusive Elite badges and indicators
- Maximum refinement in all visual elements

## Android-Specific Considerations

### Material Design Integration
- Follow Material Design guidelines while maintaining brand identity
- Use standard Android navigation patterns where appropriate
- Implement proper elevation and shadow effects

### Responsive Layouts
- Support for multiple screen sizes and orientations
- Adaptive layouts for different device capabilities
- Proper handling of system UI elements (status bar, navigation bar)

### Performance Optimization
- Optimize animations for smooth performance
- Efficient image loading and caching
- Minimize overdraw and layout complexity

## Implementation Guidelines

### Asset Preparation
- Export icons in multiple densities (mdpi, hdpi, xhdpi, xxhdpi, xxxhdpi)
- Use vector drawables where possible
- Optimize image assets for file size and quality

### Code Standards
- Use resource files for colors, dimensions, and styles
- Implement theme attributes for consistent styling
- Create reusable custom views for complex UI components

### Quality Assurance
- Test on multiple device sizes and resolutions
- Verify accessibility with screen readers and contrast checkers
- Ensure consistent implementation across all screens
