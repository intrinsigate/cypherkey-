from PIL import Image, ImageDraw, ImageFont
import os

# Create directory for wireframe images
os.makedirs('/home/ubuntu/membership_app_project/ui_design/wireframes/images', exist_ok=True)

# Define colors
BACKGROUND = (250, 250, 250)
ELEMENT_BG = (240, 240, 240)
TEXT = (60, 60, 60)
PRIMARY = (100, 100, 240)
SECONDARY = (180, 180, 180)
ACCENT = (255, 140, 0)

# Define dimensions for mobile screen (Android)
WIDTH = 360
HEIGHT = 640

def create_base_screen(title):
    """Create a base screen with status bar and title"""
    img = Image.new('RGB', (WIDTH, HEIGHT), BACKGROUND)
    draw = ImageDraw.Draw(img)
    
    # Status bar
    draw.rectangle([(0, 0), (WIDTH, 30)], fill=(240, 240, 240))
    
    # Title bar
    draw.rectangle([(0, 30), (WIDTH, 80)], fill=PRIMARY)
    
    # Title text
    draw.text((WIDTH//2, 55), title, fill=(255, 255, 255), anchor="mm")
    
    return img, draw

def draw_bottom_nav(draw):
    """Draw bottom navigation bar"""
    draw.rectangle([(0, HEIGHT-60), (WIDTH, HEIGHT)], fill=ELEMENT_BG)
    
    # Nav items
    icons = ["Home", "Tools", "Discover", "Insights", "Profile"]
    icon_width = WIDTH // len(icons)
    
    for i, icon in enumerate(icons):
        x = i * icon_width + icon_width // 2
        draw.text((x, HEIGHT-40), icon, fill=TEXT, anchor="mm")
        draw.ellipse([(x-15, HEIGHT-25), (x+15, HEIGHT-15)], outline=TEXT)

def draw_card(draw, x, y, width, height, title, subtitle=None, has_image=False):
    """Draw a content card"""
    draw.rectangle([(x, y), (x+width, y+height)], fill=ELEMENT_BG, outline=SECONDARY)
    
    if has_image:
        draw.rectangle([(x, y), (x+width, y+width*0.6)], fill=ACCENT)
        draw.text((x+width//2, y+width*0.3), "IMAGE", fill=(255, 255, 255), anchor="mm")
        text_y = y + width*0.6 + 15
    else:
        text_y = y + 15
    
    draw.text((x+10, text_y), title, fill=TEXT)
    
    if subtitle:
        draw.text((x+10, text_y+20), subtitle, fill=SECONDARY)

def draw_button(draw, x, y, width, height, text, primary=True):
    """Draw a button"""
    color = PRIMARY if primary else SECONDARY
    draw.rectangle([(x, y), (x+width, y+height)], fill=color, outline=color)
    draw.text((x+width//2, y+height//2), text, fill=(255, 255, 255), anchor="mm")

def draw_input(draw, x, y, width, height, placeholder):
    """Draw an input field"""
    draw.rectangle([(x, y), (x+width, y+height)], fill=BACKGROUND, outline=SECONDARY)
    draw.text((x+10, y+height//2), placeholder, fill=SECONDARY, anchor="lm")

def draw_tab_bar(draw, x, y, width, tabs, active_index=0):
    """Draw a tab bar"""
    tab_width = width // len(tabs)
    
    for i, tab in enumerate(tabs):
        tab_x = x + i * tab_width
        tab_color = PRIMARY if i == active_index else BACKGROUND
        text_color = (255, 255, 255) if i == active_index else TEXT
        
        draw.rectangle([(tab_x, y), (tab_x+tab_width, y+40)], fill=tab_color)
        draw.text((tab_x+tab_width//2, y+20), tab, fill=text_color, anchor="mm")

# 1. Welcome/Splash Screen
img, draw = create_base_screen("")
draw.rectangle([(0, 0), (WIDTH, HEIGHT)], fill=PRIMARY)
draw.text((WIDTH//2, HEIGHT//2-50), "ELEVATE", fill=(255, 255, 255), anchor="mm", font_size=36)
draw.text((WIDTH//2, HEIGHT//2), "Elevate Your Potential", fill=(255, 255, 255), anchor="mm")
draw_button(draw, WIDTH//2-100, HEIGHT-150, 200, 50, "Get Started")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/01_welcome.png')

# 2. Sign Up Screen
img, draw = create_base_screen("Create Account")
draw_input(draw, 30, 100, WIDTH-60, 50, "Email")
draw_input(draw, 30, 170, WIDTH-60, 50, "Password")
draw_input(draw, 30, 240, WIDTH-60, 50, "Confirm Password")
draw_button(draw, 30, 320, WIDTH-60, 50, "Sign Up")
draw.text((WIDTH//2, 390), "Or sign up with", fill=TEXT, anchor="mm")
draw.rectangle([(WIDTH//2-80, 420), (WIDTH//2-20, 460)], outline=SECONDARY)
draw.text((WIDTH//2-50, 440), "G", fill=TEXT, anchor="mm")
draw.rectangle([(WIDTH//2+20, 420), (WIDTH//2+80, 460)], outline=SECONDARY)
draw.text((WIDTH//2+50, 440), "f", fill=TEXT, anchor="mm")
draw.text((WIDTH//2, 500), "Already have an account? Log In", fill=PRIMARY, anchor="mm")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/02_signup.png')

# 3. Onboarding - Interests
img, draw = create_base_screen("Your Interests")
draw.text((30, 100), "Select topics that interest you:", fill=TEXT)
interests = ["Productivity", "Personal Growth", "Creativity", "Finance", "Health", "Technology"]
for i, interest in enumerate(interests):
    row = i // 2
    col = i % 2
    x = 30 + col * (WIDTH//2 - 30)
    y = 140 + row * 70
    draw.rectangle([(x, y), (x+WIDTH//2-60, y+50)], outline=SECONDARY)
    draw.text((x+10, y+25), interest, fill=TEXT, anchor="lm")
draw_button(draw, 30, HEIGHT-100, WIDTH-60, 50, "Continue")
draw.rectangle([(WIDTH//2-100, HEIGHT-30), (WIDTH//2+100, HEIGHT-20)], fill=SECONDARY)
draw.rectangle([(WIDTH//2-100, HEIGHT-30), (WIDTH//2-70, HEIGHT-20)], fill=PRIMARY)
draw.text((WIDTH//2, HEIGHT-45), "Step 1 of 3", fill=TEXT, anchor="mm")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/03_onboarding_interests.png')

# 4. Membership Selection
img, draw = create_base_screen("Choose Your Plan")
plans = ["Essentials", "Plus", "Pro", "Elite"]
descriptions = ["Free", "$9.99/mo", "$19.99/mo", "$29.99/mo"]
for i, (plan, desc) in enumerate(zip(plans, descriptions)):
    y = 100 + i * 120
    draw.rectangle([(30, y), (WIDTH-30, y+100)], fill=ELEMENT_BG, outline=SECONDARY)
    draw.text((50, y+20), plan, fill=TEXT)
    draw.text((50, y+45), desc, fill=SECONDARY)
    if i == 0:
        draw_button(draw, WIDTH-120, y+25, 70, 50, "Current", primary=False)
    else:
        draw_button(draw, WIDTH-120, y+25, 70, 50, "Select")
draw.text((WIDTH//2, HEIGHT-45), "You can change your plan anytime", fill=SECONDARY, anchor="mm")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/04_membership_selection.png')

# 5. Home Dashboard
img, draw = create_base_screen("Home")
draw.text((30, 100), "Welcome back, Alex", fill=TEXT)
draw.text((30, 130), "Your daily recommendations", fill=SECONDARY)
draw_card(draw, 30, 160, WIDTH-60, 120, "Complete your morning routine", "5 steps remaining", has_image=True)
draw.text((30, 300), "Continue your progress", fill=SECONDARY)
draw_card(draw, 30, 330, (WIDTH-70)//2, 100, "Productivity", "75% complete")
draw_card(draw, WIDTH//2+10, 330, (WIDTH-70)//2, 100, "Mindfulness", "30% complete")
draw.text((30, 450), "Trending in community", fill=SECONDARY)
draw_card(draw, 30, 480, WIDTH-60, 80, "10 ways to improve focus", "Article • 5 min read")
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/05_home_dashboard.png')

# 6. Tools Section
img, draw = create_base_screen("Tools")
draw_tab_bar(draw, 0, 80, WIDTH, ["All", "Productivity", "Growth", "Finance"], 0)
draw_card(draw, 30, 140, (WIDTH-70)//2, 120, "Task Manager", has_image=True)
draw_card(draw, WIDTH//2+10, 140, (WIDTH-70)//2, 120, "Notes", has_image=True)
draw_card(draw, 30, 280, (WIDTH-70)//2, 120, "Habit Tracker", has_image=True)
draw_card(draw, WIDTH//2+10, 280, (WIDTH-70)//2, 120, "Goal Setting", has_image=True)
draw_card(draw, 30, 420, (WIDTH-70)//2, 120, "Focus Timer", has_image=True)
draw_card(draw, WIDTH//2+10, 420, (WIDTH-70)//2, 120, "Calendar", has_image=True)
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/06_tools_section.png')

# 7. Tool Detail - Task Manager
img, draw = create_base_screen("Task Manager")
draw_button(draw, WIDTH-90, 40, 60, 30, "+ New", primary=False)
draw_tab_bar(draw, 0, 80, WIDTH, ["Today", "Upcoming", "Projects"], 0)
tasks = ["Complete wireframe design", "Team meeting", "Research competitors", "Update documentation"]
for i, task in enumerate(tasks):
    y = 140 + i * 60
    draw.rectangle([(30, y), (WIDTH-30, y+50)], fill=ELEMENT_BG, outline=SECONDARY)
    draw.rectangle([(40, y+15), (60, y+35)], outline=SECONDARY)
    draw.text((80, y+25), task, fill=TEXT, anchor="lm")
draw_button(draw, WIDTH//2-75, HEIGHT-100, 150, 50, "+ Add Task")
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/07_tool_detail_tasks.png')

# 8. Workflows Section
img, draw = create_base_screen("Workflows")
draw_tab_bar(draw, 0, 80, WIDTH, ["Featured", "My Workflows", "Browse"], 0)
draw_card(draw, 30, 140, WIDTH-60, 150, "Morning Productivity Routine", "5 steps • 25 minutes", has_image=True)
draw_card(draw, 30, 310, WIDTH-60, 150, "Deep Work Session", "4 steps • 2 hours", has_image=True)
draw_card(draw, 30, 480, WIDTH-60, 150, "Evening Reflection", "3 steps • 15 minutes", has_image=True)
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/08_workflows.png')

# 9. Workflow Detail
img, draw = create_base_screen("Morning Routine")
draw.rectangle([(0, 80), (WIDTH, 200)], fill=ACCENT)
draw.text((WIDTH//2, 140), "IMAGE", fill=(255, 255, 255), anchor="mm")
draw.text((30, 220), "Morning Productivity Routine", fill=TEXT)
draw.text((30, 250), "5 steps • 25 minutes", fill=SECONDARY)
draw.text((30, 280), "Description:", fill=TEXT)
draw.text((30, 310), "Start your day with focus and intention with this", fill=SECONDARY)
draw.text((30, 330), "proven morning routine for peak productivity.", fill=SECONDARY)
draw.text((30, 370), "Steps:", fill=TEXT)
steps = ["Mindful breathing - 5 min", "Goal setting - 5 min", "Priority planning - 5 min", 
         "Quick exercise - 5 min", "Focus block - 5 min"]
for i, step in enumerate(steps):
    y = 400 + i * 40
    draw.text((50, y), f"{i+1}. {step}", fill=TEXT)
draw_button(draw, 30, HEIGHT-100, WIDTH-60, 50, "Start Workflow")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/09_workflow_detail.png')

# 10. Insights Section
img, draw = create_base_screen("Insights")
draw_tab_bar(draw, 0, 80, WIDTH, ["For You", "Trending", "Saved"], 0)
draw_card(draw, 30, 140, WIDTH-60, 150, "How to Build Lasting Habits", "Article • 8 min read", has_image=True)
draw_card(draw, 30, 310, WIDTH-60, 150, "The Science of Productivity", "Article • 12 min read", has_image=True)
draw_card(draw, 30, 480, WIDTH-60, 150, "Focus in a Distracted World", "Video • 15 min", has_image=True)
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/10_insights.png')

# 11. Insight Detail
img, draw = create_base_screen("Article")
draw.rectangle([(0, 80), (WIDTH, 200)], fill=ACCENT)
draw.text((WIDTH//2, 140), "IMAGE", fill=(255, 255, 255), anchor="mm")
draw.text((30, 220), "How to Build Lasting Habits", fill=TEXT)
draw.text((30, 250), "By Dr. James Clear • 8 min read", fill=SECONDARY)
draw.line([(30, 280), (WIDTH-30, 280)], fill=SECONDARY)
draw.text((30, 300), "Lorem ipsum dolor sit amet, consectetur adipiscing", fill=TEXT)
draw.text((30, 320), "elit. Sed do eiusmod tempor incididunt ut labore", fill=TEXT)
draw.text((30, 340), "et dolore magna aliqua. Ut enim ad minim veniam,", fill=TEXT)
draw.text((30, 360), "quis nostrud exercitation ullamco laboris nisi ut", fill=TEXT)
draw.text((30, 380), "aliquip ex ea commodo consequat.", fill=TEXT)
draw.text((30, 420), "Duis aute irure dolor in reprehenderit in voluptate", fill=TEXT)
draw.text((30, 440), "velit esse cillum dolore eu fugiat nulla pariatur.", fill=TEXT)
draw.rectangle([(WIDTH-60, 500), (WIDTH-30, 530)], outline=SECONDARY)
draw.text((WIDTH-45, 515), "♡", fill=SECONDARY, anchor="mm")
draw.rectangle([(WIDTH-100, 500), (WIDTH-70, 530)], outline=SECONDARY)
draw.text((WIDTH-85, 515), "⋮", fill=SECONDARY, anchor="mm")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/11_insight_detail.png')

# 12. Discoveries Section
img, draw = create_base_screen("Discover")
draw.text((30, 100), "Recommended for you", fill=TEXT)
draw_card(draw, 30, 130, (WIDTH-70)//2, 120, "Focus Timer", "Tool", has_image=True)
draw_card(draw, WIDTH//2+10, 130, (WIDTH-70)//2, 120, "Deep Work", "Workflow", has_image=True)
draw.text((30, 270), "New this week", fill=TEXT)
draw_card(draw, 30, 300, WIDTH-60, 120, "Creativity Workshop", "Live event • Apr 20", has_image=True)
draw.text((30, 440), "Popular in community", fill=TEXT)
draw_card(draw, 30, 470, (WIDTH-70)//2, 120, "Habit Building", "Discussion", has_image=False)
draw_card(draw, WIDTH//2+10, 470, (WIDTH-70)//2, 120, "Focus Tips", "Thread", has_image=False)
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/12_discoveries.png')

# 13. Entertainment Section
img, draw = create_base_screen("Entertainment")
draw_tab_bar(draw, 0, 80, WIDTH, ["Videos", "Audio", "Interactive"], 0)
draw_card(draw, 30, 140, WIDTH-60, 150, "The Science of Flow State", "Video • 18 min", has_image=True)
draw_card(draw, 30, 310, WIDTH-60, 150, "Mindfulness Meditation", "Audio • 10 min", has_image=True)
draw_card(draw, 30, 480, WIDTH-60, 150, "Creativity Challenge", "Interactive • 15 min", has_image=True)
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/13_entertainment.png')

# 14. Community Section
img, draw = create_base_screen("Community")
draw_tab_bar(draw, 0, 80, WIDTH, ["Feed", "Groups", "Events"], 0)
draw_card(draw, 30, 140, WIDTH-60, 180, "How do you maintain focus during long work sessions?", "Discussion • 28 comments • 2h ago", has_image=False)
draw.text((50, 200), "Started by Alex Chen", fill=SECONDARY)
draw_card(draw, 30, 340, WIDTH-60, 180, "Share your productivity wins this week!", "Discussion • 42 comments • 5h ago", has_image=False)
draw.text((50, 400), "Started by Jamie Smith", fill=SECONDARY)
draw_button(draw, WIDTH-90, HEIGHT-120, 60, 60, "+", primary=True)
draw_bottom_nav(draw)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/14_community.png')

# 15. Profile & Settings
img, draw = create_base_screen("Profile")
draw.ellipse([(WIDTH//2-50, 100), (WIDTH//2+50, 200)], outline=SECONDARY)
draw.text((WIDTH//2, 150), "PHOTO", fill=SECONDARY, anchor="mm")
draw.text((WIDTH//2, 220), "Alex Chen", fill=TEXT, anchor="mm")
draw.text((WIDTH//2, 245), "Elevate Plus Member", fill=SECONDARY, anchor="mm")
draw.line([(30, 280), (WIDTH-30, 280)], fill=SECONDARY)
menu_items = ["My Progress", "Saved Items", "Notifications", "Account Settings", "Subscription", "Help & Support"]
for i, item in enumerate(menu_items):
    y = 300 + i * 50
    draw.text((50, y), item, fill=TEXT)
    draw.text((WIDTH-50, y), ">", fill=SECONDARY, anchor="rm")
    draw.line([(30, y+25), (WIDTH-30, y+25)], fill=SECONDARY)
draw_button(draw, 30, HEIGHT-100, WIDTH-60, 50, "Log Out", primary=False)
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/15_profile.png')

# 16. Upgrade Comparison
img, draw = create_base_screen("Upgrade Your Plan")
draw.text((30, 100), "Choose the plan that's right for you:", fill=TEXT)
plans = ["Plus", "Pro", "Elite"]
prices = ["$9.99/mo", "$19.99/mo", "$29.99/mo"]
for i, (plan, price) in enumerate(zip(plans, prices)):
    y = 140 + i * 150
    draw.rectangle([(30, y), (WIDTH-30, y+130)], fill=ELEMENT_BG, outline=SECONDARY)
    draw.text((50, y+20), plan, fill=TEXT)
    draw.text((50, y+45), price, fill=SECONDARY)
    features = ["Basic" if i == 0 else "Advanced" if i == 1 else "Premium"]
    draw.text((50, y+70), f"• {features} tools & workflows", fill=TEXT)
    draw.text((50, y+95), f"• {'Limited' if i == 0 else 'Full'} community access", fill=TEXT)
    draw_button(draw, WIDTH-120, y+40, 70, 50, "Select")
img.save('/home/ubuntu/membership_app_project/ui_design/wireframes/images/16_upgrade_comparison.png')

print("Wireframes generated successfully!")
