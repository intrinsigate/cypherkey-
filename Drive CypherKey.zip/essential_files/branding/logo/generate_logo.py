from PIL import Image, ImageDraw, ImageFont
import os

# Create directory for logo files
os.makedirs('/home/ubuntu/membership_app_project/branding/logo', exist_ok=True)

# Define colors
ROYAL_PURPLE = (106, 90, 205)  # #6A5ACD
DEEP_INDIGO = (75, 0, 130)     # #4B0082
SOFT_GOLD = (212, 175, 55)     # #D4AF37
WHITE = (255, 255, 255)

def create_logo(size, bg_color, fg_color, accent_color, with_text=True, with_tagline=False):
    """Create the Elevate logo with optional text and tagline"""
    # Create a blank image with the specified background color
    img = Image.new('RGB', (size, size), bg_color)
    draw = ImageDraw.Draw(img)
    
    # Calculate dimensions
    margin = size // 10
    icon_size = size - (2 * margin)
    
    # Draw the upward arrow/mountain shape (representing elevation)
    # Triangle base points
    left_base = (margin + icon_size * 0.2, margin + icon_size * 0.8)
    right_base = (margin + icon_size * 0.8, margin + icon_size * 0.8)
    # Triangle peak
    peak = (margin + icon_size * 0.5, margin + icon_size * 0.2)
    
    # Draw the main triangle
    draw.polygon([left_base, right_base, peak], fill=fg_color)
    
    # Draw the accent line (representing the path of elevation)
    line_start = (margin + icon_size * 0.35, margin + icon_size * 0.65)
    line_mid = (margin + icon_size * 0.5, margin + icon_size * 0.4)
    line_end = (margin + icon_size * 0.65, margin + icon_size * 0.65)
    
    # Draw a curved path
    for t in range(0, 101, 2):
        t = t / 100.0
        # Quadratic Bezier curve
        x = (1-t)**2 * line_start[0] + 2*(1-t)*t*line_mid[0] + t**2*line_end[0]
        y = (1-t)**2 * line_start[1] + 2*(1-t)*t*line_mid[1] + t**2*line_end[1]
        
        # Draw a small circle at each point to create a smooth line
        circle_radius = size // 80
        draw.ellipse([(x-circle_radius, y-circle_radius), (x+circle_radius, y+circle_radius)], fill=accent_color)
    
    # Add a small circle at the peak to represent achievement/goal
    peak_circle_radius = size // 40
    draw.ellipse([(peak[0]-peak_circle_radius, peak[1]-peak_circle_radius), 
                  (peak[0]+peak_circle_radius, peak[1]+peak_circle_radius)], fill=accent_color)
    
    # If text is requested, create a new larger image to accommodate it
    if with_text:
        # Create a new image with space for text
        text_height = size // 3
        tagline_height = size // 6 if with_tagline else 0
        new_height = size + text_height + tagline_height
        
        text_img = Image.new('RGB', (size, new_height), bg_color)
        text_img.paste(img, (0, 0))
        
        # Add "ELEVATE" text
        draw = ImageDraw.Draw(text_img)
        text = "ELEVATE"
        text_y = size + (text_height // 2)
        
        # Draw the text centered
        draw.text((size // 2, text_y), text, fill=fg_color, anchor="mm")
        
        # Add tagline if requested
        if with_tagline:
            tagline = "ELEVATE YOUR POTENTIAL"
            tagline_y = size + text_height + (tagline_height // 2)
            draw.text((size // 2, tagline_y), tagline, fill=fg_color, anchor="mm")
        
        return text_img
    
    return img

# Generate logos in different sizes and variations
sizes = [512, 256, 128, 64]

for size in sizes:
    # Logo on purple background
    logo_purple_bg = create_logo(size, ROYAL_PURPLE, WHITE, SOFT_GOLD, with_text=True)
    logo_purple_bg.save(f'/home/ubuntu/membership_app_project/branding/logo/elevate_logo_purple_bg_{size}.png')
    
    # Logo on white background
    logo_white_bg = create_logo(size, WHITE, ROYAL_PURPLE, SOFT_GOLD, with_text=True)
    logo_white_bg.save(f'/home/ubuntu/membership_app_project/branding/logo/elevate_logo_white_bg_{size}.png')
    
    # Icon only (no text) on purple background
    icon_purple_bg = create_logo(size, ROYAL_PURPLE, WHITE, SOFT_GOLD, with_text=False)
    icon_purple_bg.save(f'/home/ubuntu/membership_app_project/branding/logo/elevate_icon_purple_bg_{size}.png')
    
    # Icon only (no text) on white background
    icon_white_bg = create_logo(size, WHITE, ROYAL_PURPLE, SOFT_GOLD, with_text=False)
    icon_white_bg.save(f'/home/ubuntu/membership_app_project/branding/logo/elevate_icon_white_bg_{size}.png')

# Create a special version with tagline for marketing
logo_with_tagline = create_logo(512, WHITE, ROYAL_PURPLE, SOFT_GOLD, with_text=True, with_tagline=True)
logo_with_tagline.save('/home/ubuntu/membership_app_project/branding/logo/elevate_logo_with_tagline.png')

print("Logo files generated successfully!")
