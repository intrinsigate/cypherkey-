# Elevate: Visual Identity Guide

## Logo

The Elevate logo embodies the brand's core concept of personal and professional growth. The design features a triangular mountain shape representing upward movement and elevation, with a golden path and achievement marker symbolizing the journey and accomplishment.

### Logo Variations

1. **Primary Logo**: Full logo with "ELEVATE" text on white background
2. **Reversed Logo**: Full logo with "ELEVATE" text on purple background
3. **Icon Only**: Mountain symbol without text for app icon and small applications
4. **Logo with Tagline**: Extended version including "ELEVATE YOUR POTENTIAL" tagline for marketing materials

### Logo Usage Guidelines

- Maintain clear space around the logo equal to the height of the "E" in "ELEVATE"
- Minimum size for the full logo is 64px in height to maintain legibility
- Do not stretch, distort, or alter the logo proportions
- Do not change the logo colors outside of approved variations
- Do not place the logo on busy backgrounds that reduce visibility

## Color System

### Primary Colors

- **Royal Purple** (#6A5ACD)
  - Main brand color
  - Used for primary UI elements, headers, and brand accents
  - Represents luxury, creativity, and wisdom

- **Deep Indigo** (#4B0082)
  - Secondary brand color
  - Used for depth and contrast in UI elements
  - Creates visual hierarchy and sophistication

- **Soft Gold** (#D4AF37)
  - Accent color
  - Used for highlights, achievements, and premium elements
  - Represents achievement, value, and aspiration

### Secondary Colors

- **Calm Teal** (#45B5AA)
  - Used for productivity and focus-related elements
  - Creates balance with the primary purple

- **Warm Coral** (#FF7F50)
  - Used for entertainment and discovery sections
  - Adds energy and warmth to the design

- **Sage Green** (#9DC183)
  - Used for wellness and growth-related elements
  - Represents balance and natural progression

### Neutral Colors

- **Pure White** (#FFFFFF)
  - Primary background color
  - Creates clean, open spaces

- **Soft Cream** (#F8F5F0)
  - Secondary background for cards and panels
  - Adds warmth and reduces eye strain

- **Light Gray** (#E0E0E0)
  - For subtle separators and inactive elements
  - Creates visual structure without heaviness

- **Medium Gray** (#9E9E9E)
  - For secondary text and less prominent elements
  - Ensures proper visual hierarchy

- **Charcoal** (#333333)
  - For primary text
  - Provides optimal readability while being softer than pure black

### Color Usage Guidelines

- Maintain sufficient contrast for accessibility (minimum 4.5:1 for text)
- Use primary colors for main UI elements and brand identity
- Use secondary colors to differentiate functional areas of the app
- Use neutral colors for backgrounds and supporting elements
- Reserve Soft Gold for highlighting premium features and achievements

## Typography

### Primary Font: Montserrat

Montserrat is the primary typeface for the Elevate brand, chosen for its modern, clean aesthetic and excellent readability across devices.

#### Weights and Usage

- **Montserrat Light (300)**
  - Body text and secondary information
  - Captions and fine print

- **Montserrat Regular (400)**
  - General UI text
  - Descriptions and content

- **Montserrat Medium (500)**
  - Emphasis and subheadings
  - Button text and interactive elements

- **Montserrat SemiBold (600)**
  - Headings and important UI elements
  - Navigation labels

- **Montserrat Bold (700)**
  - Primary buttons and main headings
  - Feature highlights

### Secondary Font: Playfair Display

Playfair Display is used sparingly to add elegance and distinction to featured content.

#### Usage

- Featured quotes and testimonials
- Special section headings
- Marketing materials where elegance is emphasized

### Typography Hierarchy

- **H1 (28px)**: Main screen titles and primary marketing headlines
- **H2 (24px)**: Section headers and secondary marketing headlines
- **H3 (20px)**: Card titles and feature headings
- **H4 (18px)**: Subsection headers and emphasized content
- **Body (16px)**: Standard content text
- **Small (14px)**: Secondary information and supporting text
- **Caption (12px)**: Labels, timestamps, and metadata

### Typography Guidelines

- Maintain consistent line height (1.5 for body text)
- Ensure adequate spacing between paragraphs
- Limit line length to 60-75 characters for optimal readability
- Use proper hierarchy to guide users through content
- Avoid using more than two font families in any design

## Iconography

### Style Characteristics

- **Line Weight**: 2px stroke for outlined icons
- **Corner Radius**: 2px for sharp corners, 4px for rounded elements
- **Style**: Modern, minimalist with occasional decorative elements for premium features
- **Consistency**: All icons follow the same visual language and proportions

### Icon Categories

1. **Navigation Icons**
   - Simple, recognizable symbols for main app sections
   - Consistent style across bottom navigation and menus

2. **Action Icons**
   - Clear, intuitive representations of common actions
   - Used for interactive elements throughout the app

3. **Status Icons**
   - Distinct shapes for different status indicators
   - Used to communicate state and progress

4. **Feature Icons**
   - Distinctive representations of app features
   - More detailed than navigation icons but maintain consistent style

5. **Tier Badges**
   - Unique emblems for each membership tier
   - Incorporate tier-specific colors and elements

### Icon Usage Guidelines

- Maintain consistent padding within the icon bounding box
- Use the same visual weight across the icon system
- Ensure icons are recognizable at small sizes (minimum 24x24px)
- Use color sparingly and purposefully within icons
- Provide text labels alongside icons for clarity when appropriate

## Imagery

### Photography Style

- **Lifestyle**: Aspirational but authentic images of people using the app features
  - Natural lighting
  - Diverse representation
  - Genuine expressions and activities

- **Abstract**: Subtle patterns and textures for backgrounds and accents
  - Geometric shapes that suggest upward movement
  - Gradient effects that incorporate brand colors
  - Light and airy compositions

- **Conceptual**: Visual metaphors representing growth, elevation, and potential
  - Mountain imagery
  - Upward trajectories
  - Achievement moments

### Illustration Style

- **Style**: Modern, slightly abstract with organic shapes
- **Color Use**: Limited palette using brand colors
- **Purpose**: Explain concepts, visualize data, and add visual interest
- **Consistency**: All illustrations share the same visual language

### Imagery Guidelines

- Select images that reinforce the brand's sophisticated, inspiring personality
- Ensure all imagery is high-quality and properly optimized for digital use
- Maintain consistent treatment across all imagery (color grading, cropping, etc.)
- Use imagery purposefully to enhance understanding or emotional connection
- Ensure diverse and inclusive representation in all people-focused imagery

## UI Elements

### Buttons

- **Primary Button**
  - Royal Purple background
  - White text
  - Subtle gradient
  - 8px rounded corners
  - Subtle shadow
  - 16px vertical padding, 24px horizontal padding

- **Secondary Button**
  - White background
  - Royal Purple border and text
  - 8px rounded corners
  - 16px vertical padding, 24px horizontal padding

- **Tertiary Button**
  - No background
  - Royal Purple text
  - No border
  - 16px vertical padding, 24px horizontal padding

### Cards

- **Standard Card**
  - White background
  - Subtle shadow (2px blur, 1px y-offset)
  - 12px rounded corners
  - 16px padding
  - Optional dividers between content sections

- **Featured Card**
  - Soft Cream background
  - Medium shadow (4px blur, 2px y-offset)
  - 12px rounded corners
  - 16px padding
  - Soft Gold accent elements

- **Tier Card**
  - Gradient background based on tier level
  - Medium shadow (4px blur, 2px y-offset)
  - 12px rounded corners
  - 16px padding
  - Tier-specific accent elements

### Navigation Elements

- **Bottom Navigation**
  - White background
  - Royal Purple active indicator
  - Icons with labels
  - 56px height

- **Tab Bar**
  - White background
  - Royal Purple underline for active tab
  - 48px height

- **Drawer Menu**
  - White background
  - Royal Purple accent for active item
  - 16px padding for menu items

### Form Elements

- **Text Input**
  - White background
  - Light Gray border
  - 8px rounded corners
  - 12px padding
  - Focused state: Royal Purple border

- **Dropdown**
  - White background
  - Light Gray border
  - 8px rounded corners
  - 12px padding
  - Expanded state: Medium shadow

- **Checkbox**
  - Royal Purple when checked
  - Light Gray border when unchecked
  - 2px border radius

- **Radio Button**
  - Royal Purple when selected
  - Light Gray border when unselected
  - Circular shape

- **Toggle**
  - Royal Purple when on
  - Light Gray when off
  - 24px height

## Animation & Motion

### Principles

- **Purposeful**: Animations serve functional purposes, not just decoration
- **Smooth**: Fluid transitions between states and screens
- **Subtle**: Understated effects that don't distract from content

### Specific Animations

- **Transitions**: Smooth fade and slide effects between screens (300ms duration)
- **Feedback**: Subtle scale and color changes for interactive elements (150ms duration)
- **Progress**: Elegant loading indicators and progress animations
- **Celebration**: More expressive animations for achievements and milestones

### Animation Guidelines

- Keep animations under 500ms for transitions
- Use standard easing curves (ease-in-out for most transitions)
- Ensure animations can be disabled for users who prefer reduced motion
- Use consistent timing and easing across similar animation types
- Test animations on target devices to ensure smooth performance

## Tier-Specific Visual Elements

### Essentials (Free)

- Standard UI components
- Limited access indicators for premium features
- Basic animations and transitions
- Primary color palette only

### Plus

- Enhanced card styles with subtle gradients
- Improved animations and transitions
- Custom icons for Plus features
- Introduction of secondary colors

### Pro

- Premium card styles with deeper shadows and refined details
- Advanced animations and transitions
- Exclusive Pro badges and indicators
- Refined typography with more Playfair Display usage
- Full color palette utilization

### Elite

- Luxury card styles with gold accents and distinctive details
- Premium animations with polished effects
- Exclusive Elite badges and indicators
- Maximum refinement in all visual elements
- Special gold highlights and exclusive patterns

## Application Examples

### App Icon

The app icon uses the mountain symbol on a Royal Purple background, creating a distinctive and recognizable presence on the user's device.

### Splash Screen

The splash screen features the full logo centered on a Royal Purple background, creating an elegant first impression.

### Marketing Materials

Marketing materials combine the logo with tagline, aspirational imagery, and clear value propositions using the full brand color palette and typography system.

### Social Media

Social media assets maintain consistent branding while adapting to platform-specific requirements, always featuring the logo and core brand colors.

## Accessibility Guidelines

- Maintain minimum 4.5:1 contrast ratio for all text elements
- Provide alternative visual indicators beyond color alone
- Ensure touch targets are minimum 44x44px
- Support text scaling up to 200% without loss of functionality
- Test with screen readers and other assistive technologies

## File Formats and Resources

- Logo files are available in PNG format at multiple resolutions
- Icon assets should be implemented as vector drawables where possible
- Color values are defined in HEX for digital applications
- Typography is implemented using standard Android font integration

## Conclusion

This visual identity guide provides a comprehensive framework for creating a consistent, premium brand experience across all touchpoints of the Elevate app. By following these guidelines, all visual elements will work together to reinforce the brand's sophisticated, inspiring, and premium positioning while ensuring a user-friendly and accessible experience.
